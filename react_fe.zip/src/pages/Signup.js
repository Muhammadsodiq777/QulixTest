import '../App.css';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import TextField from '@mui/material/TextField';
import Card from '../components/Card';
const Signup = () => {
  const navigate = useNavigate();
  const [values, setValues] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    phoneNumber: '',
  });
  const handleChange = (event) => {
    setValues({
      ...values,
      [event.target.name]: event.target.value,
    });
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(values);
    fetch(`https://localhost:7106/api/Account/Register/register`, {
      method: 'POST',
      headers: {
        'Content-type': 'application/json',
      },
      body: JSON.stringify(values),
    }).then((res) => {
      const access_token = res.access_token;
      localStorage.setItem('access_token', access_token);
      navigate('/upload');
    });
  };
  return (
    <Card>
      <div className="signup-wrapper">
        <h1 className="title">Create Account</h1>
        <form className="signup">
          <TextField
            className="textField"
            label="First Name"
            variant="outlined"
            id="firstName"
            type="text"
            name="firstName"
            value={values.firstName}
            onChange={handleChange}
          />
          <TextField
            className="textField"
            label="Last Name"
            variant="outlined"
            id="lastName"
            type="text"
            name="lastName"
            value={values.lastName}
            onChange={handleChange}
          />
          <TextField
            className="textField"
            label="Phone Number"
            variant="outlined"
            id="phoneNumber"
            type="text"
            name="phoneNumber"
            value={values.phoneNumber}
            onChange={handleChange}
          />
          <TextField
            className="textField"
            label="Email"
            variant="outlined"
            id="email"
            type="email"
            name="email"
            value={values.email}
            onChange={handleChange}
          />
          <TextField
            className="textField"
            label="Password"
            variant="outlined"
            id="password"
            type="password"
            name="password"
            value={values.password}
            onChange={handleChange}
          />

          <div className="btn">
            <button onClick={handleSubmit} className="submit">
              Sign Up
            </button>
          </div>
        </form>
      </div>
    </Card>
  );
};
export default Signup;
