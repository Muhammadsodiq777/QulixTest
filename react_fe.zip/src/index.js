import ReactDOM from 'react-dom';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import Signup from './pages/Signup';
import FileUpload from './pages/UploadFiles';
export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path={'/' || 'login'} element={<Login />} />
        <Route path="signup" element={<Signup />} />
        <Route path="upload" element={<FileUpload />} />
      </Routes>
    </BrowserRouter>
  );
}

ReactDOM.render(<App />, document.getElementById('root'));
