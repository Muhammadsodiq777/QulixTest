import React from 'react';
import Card from '../components/Card';

class FileUpload extends React.Component {
  state = {
    files: null,
  };

  handleFile(e) {
    let files = e.target.files;
    this.setState({ files });
  }

  handleUpload(e) {
    let files = this.state.files;

    let formData = new FormData();
    formData.append('files', files);
    console.log(files, formData);
    fetch('https://localhost:7106/api/upload', {
      method: 'POST',
      headers: {
        'Content-Type': 'multiplatform/form-data',
        // authorization: 'your token comes here',
      },
      body: formData,
    })
      .then((res) => {})
      .catch((err) => {
        throw new Error('Cannot upload!', err);
      });
  }

  render() {
    return (
      <Card>
        <h1 className="title">Select your files</h1>
        <input type="file" multiple="multiple" onChange={(e) => this.handleFile(e)} />
        <button onClick={(e) => this.handleUpload(e)}>Send Files</button>
      </Card>
    );
  }
}

export default FileUpload;
