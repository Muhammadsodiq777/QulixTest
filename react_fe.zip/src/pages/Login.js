import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import TextField from '@mui/material/TextField';
import Card from '../components/Card';
const Login = () => {
  const navigate = useNavigate();
  const [loginValues, setLoginValues] = useState({
    email: '',
    password: '',
  });
  const handleChange = (event) => {
    setLoginValues({
      ...loginValues,
      [event.target.name]: event.target.value,
    });
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    fetch(`https://localhost:7106/api/Account/Login/login`, {
      method: 'POST',
      headers: {
        'Content-type': 'application/json',
      },
      body: JSON.stringify(loginValues),
    })
      .then((res) => res.json())
      .then((res) => {
        const access_token = res.access_token;
        localStorage.setItem('access_token', access_token);
        navigate('/upload');
      });
  };
  return (
    <Card>
      <div className="signin-wrapper">
        <h1 className="title">Login</h1>
        <form className="login">
          <TextField
            className="textField"
            label="Email"
            variant="outlined"
            type="email"
            name="email"
            value={loginValues.email}
            onChange={handleChange}
          />
          <TextField
            className="textField"
            label="Password"
            variant="outlined"
            type="password"
            name="password"
            value={loginValues.password}
            onChange={handleChange}
          />
          <div className="btn">
            <button onClick={handleSubmit} className="submit">
              Login
            </button>
          </div>
        </form>
      </div>
    </Card>
  );
};
export default Login;
